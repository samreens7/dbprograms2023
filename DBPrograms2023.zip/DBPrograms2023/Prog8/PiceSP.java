package com.sohambanking.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.sql.*;

/**
 * Servlet implementation class Register
 */
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int PID
		float RPRICE
		
		Connection con;
		PreparedStatement pst;
		
		try
		{
		PID=Integer.parseInt(request.getParameter("pid"));
		RPRICE=request.getParameter("price");
		
		//System.out.println(id+"  "+ps+"  "+nm+"  "+no+"  "+br+" "+mo);
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://be3ofgral0h3uhedyadg-mysql.services.clever-cloud.com:3306/be3ofgral0h3uhedyadg?user=ulqyiujwgocf1bcm&password=e9cCEbntdKIl2FxKlo7B");
		pst=con.prepareStatement("CALL PROC_PRICE_UPDATE(?,?)");
		pst.setInt(1, PID);
		pst.setFloat(2, RPRICE);
		pst.executeUpdate();
		con.close();
		System.out.println("Price reduced successfully");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
