package com.sohambanking.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.sql.*;

/**
 * Servlet implementation class Register
 */
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String mdnm,comp,conn,ram,rom,clr,scr,bttr,procs,price,rat;
		int pid;
		float price, rat;
		
		Connection con;
		PreparedStatement pst;
		
		try
		{
		pid=Integer.parseInt(request.getParameter("prodid");
		mdnm=request.getParameter("modelname");
		comp=request.getParameter("company");
		conn=request.getParameter("connectivity"));
		ram=request.getParameter("ram");
		rom=request.getParameter("rom");
		clr=request.getParameter("color");
		scr=request.getParameter("screen");
		bttr=request.getParameter("battery");
		procs=request.getParameter("processor");
		price=Float.parseInt(request.getParameter("price");
		rat=Float.parseInt(request.getParameter("rating");
		
		//System.out.println(id+"  "+ps+"  "+nm+"  "+no+"  "+br+" "+mo);
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://be3ofgral0h3uhedyadg-mysql.services.clever-cloud.com:3306/be3ofgral0h3uhedyadg?user=ulqyiujwgocf1bcm&password=e9cCEbntdKIl2FxKlo7B");
		pst=con.prepareStatement("insert into mobiles values(?,?,?,?,?,?,?,?,?,?,?,?)");
		pst.setInt(1, pid);
		pst.setString(2, mdnm);
		pst.setString(3, comp);
		pst.setString(4, conn);
		pst.setString(5, ram);
		pst.setString(6, rom);
		pst.setString(7, clr);
		pst.setString(8, scr);
		pst.setString(9, bttr);
		pst.setString(10, procs);
		pst.setFloat(11, price);
		pst.setFloat(12, rat);
		pst.executeUpdate();
		con.close();
		System.out.println("Mobile added successfully");
		response.sendRedirect("AddSuccess.jsp");
		}
		catch(Exception e)
		{
			System.out.println(e);
			response.sendRedirect("AddFailed.jsp");
		}
		
	}

}
